
var home = function (arr)
	{
		return ''+arr.length+'' ;
	};

module.exports = home;