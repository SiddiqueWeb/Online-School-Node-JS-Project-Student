
//Add Batch Form Validation With OnSubmit Event

function addBatch_validate(){

	//Name Validation
	var result = false;		

	if( document.addBatchForm.batchId.value == "" ){
		document.getElementById("batchId_error").innerHTML = "Please provide your Batch Id!";
		document.addBatchForm.batchId.focus();
		return false;				
	} else{
		var batchId = document.addBatchForm.batchId.value;
		var error = document.getElementById("batchId_error");

		var str1 = /^[0-9]{2}-[0-9]{4}-[0-9]{1}$/;
		var op = str1.test(batchId);
		if(op){
			error.innerHTML = "";
			
			result = true;
			
			document.addBatchForm.course.focus();
		} else{
			error.innerHTML = "Only allow Number 16-1234-2";
			document.addBatchForm.batchId.focus();
			return false;
		}	
	}
						
	//Course
	if( document.addBatchForm.course.value == "" ){
		document.getElementById('course_error').innerHTML = "Please provide your Course name!";
		document.addBatchForm.course.focus();
		return false;
	} else{
		var course = document.addBatchForm.course.value;
		var str2 = /^[a-zA-Z ]+$/;
		var op = str2.test(course);
		if(op){
			document.getElementById("course_error").innerHTML = "";
			
			result = true;
			
			document.addBatchForm.courseId.focus();
		}else{
			document.getElementById("course_error").innerHTML = "Only allow letter & white space";
			document.addBatchForm.course.focus();
			return false;
		}	
	}

	//Course Id
	if( document.addBatchForm.courseId.value == "" ){
		document.getElementById("courseId_error").innerHTML = "Please provide your Course Id!";
		document.addBatchForm.courseId.focus();
		return false;				
	} else{
		var courseId = document.addBatchForm.courseId.value;
		var str3 = /^[0-9]{4}$/;
		var op = str3.test(courseId);
		if(op){
			document.getElementById("courseId_error").innerHTML = "";
			
			result = true;
			
			document.addBatchForm.course_teacher.focus();
		} else{
			document.getElementById("courseId_error").innerHTML = "Only allow Number 1234";
			document.addBatchForm.courseId.focus();
			return false;
		}	
	}

	//Course Teacher
	if( document.addBatchForm.course_teacher.value == "" ){
		document.getElementById('course_teacher_error').innerHTML = "Please provide your Course Teacher name!";
		document.addBatchForm.course_teacher.focus();
		return false;
	} else{
		var course_teacher = document.addBatchForm.course_teacher.value;
		var str4 = /^[a-zA-Z ]+$/;
		var op = str4.test(course_teacher);
		if(op){
			document.getElementById("course_teacher_error").innerHTML = "";

			result = true;
			
			document.addBatchForm.schedule.focus();
		}else{
			document.getElementById("course_teacher_error").innerHTML = "Only allow letter & white space";
			document.addBatchForm.course_teacher.focus();
			return false;
		}	
	}

	//Schedule
	if( document.addBatchForm.schedule.value == "" ){
		document.getElementById('schedule_error').innerHTML = "Please provide your Schedule!";
		document.addBatchForm.schedule.focus();
		return false;
	} else{
		var schedule = document.addBatchForm.schedule.value;
		var str5 = /^[0-9]{2}:[0-9]{2}-[0-9]{2}:[0-9]{2}$/;
		var op = str5.test(schedule);
		if(op){
			document.getElementById("schedule_error").innerHTML = "";

			result = true;
			
			document.addBatchForm.schedule.focus();
		}else{
			document.getElementById("schedule_error").innerHTML = "Only allow Time Format! 00:00-00:00";
			document.addBatchForm.schedule.focus();
			return false;
		}	
	}

	return result;	
}

 
$(document).ready(function(){
	var adminicon="";
	var $txt1 = $("txtbatchid");
	var $txt2 = $("txtcourse");
	var $txt3 = $("txtcourseid");
	var $txt4 = $("txtcourseteacher");
	var $txt4 = $("txtschedule");
				
	$("input").focus(function(){
		var id = document.activeElement.id;			
		if(id=="txtbatchid"){
			$("#c1").css("color","green");
			icon = "#c1";
		}				
		if(id=="txtcourse"){
			$("#c2").css("color","green");
			icon = "#c2";
		}							
		if(id=="txtcourseid"){
			$("#c3").css("color","green");
			icon = "#c3";
		}
								
		if(id=="txtcourseteacher"){
			$("#c4").css("color","green");
			icon = "#c4";
		}

		if(id=="txtschedule"){
			$("#c5").css("color","green");
			icon = "#c5";
		}
	});
							
	$("input").blur(function(){
		$(icon).css("color","#b2b2b2");
	});
});