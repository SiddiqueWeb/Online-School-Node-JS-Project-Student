
//Add Batch Form Validation With OnSubmit Event

function addCourse_validate() {	

	//Course Id Validation
	var result = false;
	
	if( document.addCourseForm.courseId.value == "") {
		document.getElementById("icon1").innerHTML = "";
		document.getElementById("error1").innerHTML = "Please, Provide Course Id";
		document.addCourseForm.courseId.focus();
		return false;
	} else {
		
		var courseId = document.addCourseForm.courseId.value;
		var error = document.getElementById("error1");
		var icon = document.getElementById("icon1");
		
		//Check Course Id With Pattern
		
		var str1 = /^[0-9]{3}$/;
		var op = str1.test(courseId);
		
		if( op ) {
			error.innerHTML = "";
			icon.innerHTML = "&#10004";
			icon.style.color = "green";
			icon.style.fontSize = "18px";
			result = true;
			
			document.addCourseForm.course.focus();
		} else {
			error.innerHTML = "Only allow Number";
			icon.innerHTML = "&#10006";
			icon.style.color = "red";
			icon.style.fontSize = "18px";
			
			document.addCourseForm.courseId.focus();
			return false;
		}	
	}

	if( document.addCourseForm.course.value == "") {
		document.getElementById("icon2").innerHTML = "";
		document.getElementById("error2").innerHTML = "Please, Provide Course Name";
		document.addCourseForm.course.focus();
		return false;
	} else {
		var course = document.addCourseForm.course.value;
		var error = document.getElementById("error2");
		var icon = document.getElementById("icon2");
		
		//Check Course Id With Pattern
		
		var str2 = /^[a-zA-Z ]+$/;
		var op = str2.test(course);
		
		if( op ) {
			error.innerHTML = "";
			icon.innerHTML = "&#10004";
			icon.style.color = "green";
			icon.style.fontSize = "18px";
			result = true;
			
			document.addCourseForm.courseCredit.focus();
		} else {
			error.innerHTML = "Only allow letter & space";
			icon.innerHTML = "&#10006";
			icon.style.color = "red";
			icon.style.fontSize = "18px";

			document.addCourseForm.course.focus();
			return false;
		}	
	}

	if( document.addCourseForm.courseCredit.value == "") {
		document.getElementById("icon3").innerHTML = "";
		document.getElementById("error3").innerHTML = "Please, Provide Course Credit";
		document.addCourseForm.courseCredit.focus();
		return false;
	} else {
		var courseCredit = document.addCourseForm.courseCredit.value;
		var error = document.getElementById("error3");
		var icon = document.getElementById("icon3");
		
		//Check Course Id With Pattern
		
		var str3 = /^[0-9]{1}$/;
		var op = str3.test(courseCredit);
		
		if( op ) {
			error.innerHTML = "";
			icon.innerHTML = "&#10004";
			icon.style.color = "green";
			icon.style.fontSize = "18px";
			result = true;
		} else {
			error.innerHTML = "Only allow Number";
			icon.innerHTML = "&#10006";
			icon.style.color = "red";
			icon.style.fontSize = "18px";
			document.addCourseForm.courseCredit.focus();
			return false;
		}	
	}
	return result;	
}

function onkeyup_cid_validation() {
	
	var courseId = document.addCourseForm.courseId.value;
	var error = document.getElementById("error1");
	var icon = document.getElementById("icon1");
	
	if( document.addCourseForm.courseId.value == "" ) {
		
		error.innerHTML = "";
		icon.innerHTML = "";
		document.addCourseForm.courseId.focus();
		
	} else if( document.addCourseForm.courseId.value != "" ) {
		//Check Course Id With Pattern
		
		var str1 = /^[0-9]{3}$/;
		var op = str1.test(courseId);
		
		if( op ) {
			error.innerHTML = "";
			icon.innerHTML = "&#10004";
			icon.style.color = "green";
			icon.style.fontSize = "18px";
			document.addCourseForm.courseId.focus();
		} else {
			error.innerHTML = "Only allow Number";
			icon.innerHTML = "&#10006";
			icon.style.color = "red";
			icon.style.fontSize = "18px";
			document.addCourseForm.courseId.focus();
		}	
	}
}

function onkeyup_cname_validation() {
	var course = document.addCourseForm.course.value;
	var error = document.getElementById("error2");
	var icon = document.getElementById("icon2");
	
	if( document.addCourseForm.course.value == "" ) {
		
		error.innerHTML = "";
		icon.innerHTML = "";
		document.addCourseForm.course.focus();
		
	} else if( document.addCourseForm.course.value != "" ) {
		//Check Course Id With Pattern
		
		var str2 = /^[a-zA-Z ]+$/;
		var op = str2.test(course);
		
		if( op ) {
			error.innerHTML = "";
			icon.innerHTML = "&#10004";
			icon.style.color = "green";
			icon.style.fontSize = "18px";
			document.addCourseForm.course.focus();
		} else {
			error.innerHTML = "Only allow letter & space";
			icon.innerHTML = "&#10006";
			icon.style.color = "red";
			icon.style.fontSize = "18px";
			document.addCourseForm.course.focus();
		}	
	}
}

function onkeyup_credit_validation() {
	var courseCredit = document.addCourseForm.courseCredit.value;
	var error = document.getElementById("error3");
	var icon = document.getElementById("icon3");
	
	if( document.addCourseForm.courseCredit.value == "" ) {
		
		error.innerHTML = "";
		icon.innerHTML = "";
		document.addCourseForm.courseCredit.focus();
		
	} else if( document.addCourseForm.courseCredit.value != "" ) {
		//Check Course Credit With Pattern
		var str3 = /^[0-9]{1}$/;
		var op = str3.test(courseCredit);
		
		if( op ) {
			error.innerHTML = "";
			icon.innerHTML = "&#10004";
			icon.style.color = "green";
			icon.style.fontSize = "18px";
			document.addCourseForm.courseCredit.focus();
		} else {
			error.innerHTML = "Only allow Number";
			icon.innerHTML = "&#10006";
			icon.style.color = "red";
			icon.style.fontSize = "18px";
			document.addCourseForm.courseCredit.focus();
		}	
	}
}

