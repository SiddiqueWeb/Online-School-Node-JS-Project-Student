
function signin_form_validation() {
	var result = false;
	
	if( document.signinForm.studentId.value == "" ) {
		document.getElementById("icon1").innerHTML = "";
		document.getElementById("error1").innerHTML = "Please, give your Id";
		document.signinForm.studentId.focus();
		return false;
	} else {
		var id = document.signinForm.studentId.value;
		var error = document.getElementById("error1");
		var icon = document.getElementById("icon1");
		
		//Check Id With Pattern
		
		var str1 = /^[1-9]{2}-[0-9]{5,8}-[1-3]{1}$/;
		var op = str1.test(id);
		
		if( op ) {
			error.innerHTML = "";
			icon.innerHTML = "&#10004";
			icon.style.color = "green";
			icon.style.fontSize = "18px";
			
			result = true;
			
			document.signinForm.password.focus();
		} else {
			error.innerHTML = "Only allow the format XX-XXXXX-X";
			icon.innerHTML = "&#10006";
			icon.style.color = "red";
			icon.style.fontSize = "18px";
			document.signinForm.studentId.focus();
			return false;
		}	
	}
	
	if( document.signinForm.password.value == "" ) {
		document.getElementById("icon2").innerHTML = "";
		document.getElementById("error2").innerHTML = "Please, give your password";
		document.signinForm.password.focus();
		return false;
	} else {
		var password = document.signinForm.password.value;
		var error = document.getElementById("error2");
		var icon = document.getElementById("icon2");
		
		//Check Password With Pattern
		
		var str2 = /^[a-zA-Z0-9?%@]{5,10}$/;
		var op = str2.test(password);
		if( password.length < 5 && password.length > 10 ) {
			error.innerHTML = "Password length should be between 5 & 10";
			icon.innerHTML = "&#10006";
			icon.style.color = "red";
			icon.style.fontSize = "18px";
			document.signinForm.password.focus();
			return false;
		} else if( op ) {
			error.innerHTML = "";
			icon.innerHTML = "&#10004";
			icon.style.color = "green";
			icon.style.fontSize = "18px";
			
			if( result ) {
				result = true;
			} else {
				result = false;
			}
			
		} else {
			error.innerHTML = "Only allow A-Z, a-z, 0-9, @, ?, %";
			icon.innerHTML = "&#10006";
			icon.style.color = "red";
			icon.style.fontSize = "18px";
			document.signinForm.password.focus();
			return false;
		}	
	}
	return result;
}





function onkeyup_id_validation() {
	
	var id = document.signinForm.studentId.value;
	var error = document.getElementById("error1");
	var icon = document.getElementById("icon1");
	
	if( document.signinForm.studentId.value == "" ) {
		
		error.innerHTML = "";
		icon.innerHTML = "";
		document.signinForm.studentId.focus();
		
	} else if( document.signinForm.studentId.value != "" ) {
		
		
		
		//Check Id With Pattern
		
		var str1 = /^[1-9]{2}-[0-9]{5,8}-[1-3]{1}$/;
		var op = str1.test(id);
		
		if( op ) {
			error.innerHTML = "";
			icon.innerHTML = "&#10004";
			icon.style.color = "green";
			icon.style.fontSize = "18px";
			document.signinForm.studentId.focus();
		} else {
			error.innerHTML = "Only allow the format XX-XXXXX-X";
			icon.innerHTML = "&#10006";
			icon.style.color = "red";
			icon.style.fontSize = "18px";
			document.signinForm.studentId.focus();
		}
	}
}

function onkeyup_pass_validation() {
	var password = document.signinForm.password.value;
	var error = document.getElementById("error2");
	var icon = document.getElementById("icon2");
	
	if( document.signinForm.password.value == "" ) {
		
		error.innerHTML = "";
		icon.innerHTML = "";
		document.signinForm.password.focus();
		
	} else if( document.signinForm.password.value != "" ) {
		
		
		
		//Check Password With Pattern
		
		var str2 = /^[a-zA-Z0-9?%@]{5,10}$/;
		var op = str2.test(password);
		
		if( password.length < 5 || password.length > 10 ) {
			error.innerHTML = "Password length should be between 5 & 10";
			icon.innerHTML = "&#10006";
			icon.style.color = "red";
			icon.style.fontSize = "18px";
			document.signinForm.password.focus();
		} else if( op ) {
			error.innerHTML = "";
			icon.innerHTML = "&#10004";
			icon.style.color = "green";
			icon.style.fontSize = "18px";
			document.signinForm.password.focus();
		} else {
			error.innerHTML = "Only allow A-Z, a-z, 0-9, @, ?, %";
			icon.innerHTML = "&#10006";
			icon.style.color = "red";
			icon.style.fontSize = "18px";
			document.signinForm.password.focus();
		}	
	}
}